/**
 * src/js/pages/pengaturanAplikasi.js
 * [FILE BARU]
 * Menginisialisasi halaman "Pengaturan Aplikasi".
 */
import { createIcons } from '../ui.js';

export function initPengaturanAplikasi() {
  // Render semua ikon di halaman
  createIcons();
}
