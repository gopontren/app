/**
 * src/js/pages/goDakwah.js
 * [FILE BARU]
 * Menginisialisasi halaman "Go Dakwah".
 */

import { createIcons } from '../ui.js';

export function initGoDakwah() {
  // Render semua ikon di halaman
  createIcons();
}
